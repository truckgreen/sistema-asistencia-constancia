import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PWAInstallButton } from './PWAInstallButton';
import { ThemeCustomizerModal } from './ThemeCustomizerModal';
import {
  Gauge,
  CalendarDays,
  Clock,
  CalendarPlus,
  Users,
  ClipboardCheck,
  CheckCircle2,
  Inbox,
  FileHeart,
  FileSpreadsheet,
  Settings,
  UserCheck,
  CalendarRange,
  LogOut,
  ChevronDown,
  RotateCcw,
  Sparkles,
  QrCode,
  Palette,
  FileText,
  Database
} from 'lucide-react';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string, params?: any) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentView, onNavigate }) => {
  const {
    currentUser,
    users,
    logout,
    switchUser,
    resetToDefaults,
    vaciarRegistros,
    cargarDatosDemostracion,
    primaryColor,
  } = useApp();

  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [themeModalOpen, setThemeModalOpen] = useState(false);

  const isDirectivo = currentUser?.rol === 'directivo';

  const toggleDropdown = (name: string) => {
    setOpenDropdown(prev => (prev === name ? null : name));
  };

  const handleNav = (view: string, params?: any) => {
    onNavigate(view, params);
    setOpenDropdown(null);
    setMobileMenuOpen(false);
  };

  return (
    <>
      <header
        className="sticky top-0 z-40 backdrop-blur-md border-b border-white/15 text-white shadow-lg transition-colors duration-300"
        style={{ backgroundColor: primaryColor }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            
            {/* Logo & Institution Name */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => handleNav(isDirectivo ? 'director' : 'personal')}
                className="flex items-center gap-2.5 text-left group transition cursor-pointer"
              >
                {/* Official School Crest */}
                <div className="w-10 h-10 rounded-full bg-white p-0.5 border-2 border-amber-400/90 flex items-center justify-center shadow-md group-hover:scale-105 transition-transform overflow-hidden shrink-0">
                  <img
                    src="/img/logo.png"
                    alt="Logo U.E. La Constancia"
                    className="w-full h-full object-contain"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src = '/img/logoo.png';
                    }}
                  />
                </div>
                <div>
                  <span className="font-extrabold text-lg tracking-tight block leading-tight text-white group-hover:text-amber-300 transition-colors">
                    La Constancia
                  </span>
                  <span className="text-[11px] text-white/80 font-medium block">
                    U.E. Salvatorianos
                  </span>
                </div>
              </button>
            </div>

            {/* Navigation Links for Directivo or Personal */}
            <nav className="hidden lg:flex items-center gap-1">
              {isDirectivo ? (
                <>
                  <button
                    onClick={() => handleNav('director')}
                    className={`px-3 py-2 rounded-lg text-sm font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                      currentView === 'director'
                        ? 'bg-white/20 text-white font-bold shadow-sm'
                        : 'text-white/90 hover:bg-white/10 hover:text-white'
                    }`}
                  >
                    <Gauge className="w-4 h-4 text-amber-300" />
                    Resumen
                  </button>

                  {/* Dropdown: Organización */}
                  <div className="relative">
                    <button
                      onClick={() => toggleDropdown('organizacion')}
                      className={`px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-1.5 transition cursor-pointer ${
                        ['horarios', 'planificacion', 'usuarios'].includes(currentView)
                          ? 'bg-white/15 text-white font-semibold'
                          : 'text-white/90 hover:bg-white/10'
                      }`}
                    >
                      <CalendarDays className="w-4 h-4 text-emerald-300" />
                      Organización
                      <ChevronDown className="w-3.5 h-3.5 text-white/70" />
                    </button>

                    {openDropdown === 'organizacion' && (
                      <div className="absolute left-0 mt-2 w-56 bg-white rounded-xl shadow-xl py-2 border border-slate-200 text-slate-800 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                        <button
                          onClick={() => handleNav('horarios')}
                          className="w-full text-left px-4 py-2 hover:bg-slate-100 text-sm flex items-center gap-2 cursor-pointer text-slate-700"
                        >
                          <Clock className="w-4 h-4 text-emerald-700" />
                          <span>Horarios por persona</span>
                        </button>
                        <button
                          onClick={() => handleNav('planificacion')}
                          className="w-full text-left px-4 py-2 hover:bg-slate-100 text-sm flex items-center gap-2 cursor-pointer text-slate-700"
                        >
                          <CalendarPlus className="w-4 h-4 text-emerald-700" />
                          <span>Planificación y Horarios</span>
                        </button>
                        <div className="my-1 border-t border-slate-100"></div>
                        <button
                          onClick={() => handleNav('usuarios')}
                          className="w-full text-left px-4 py-2 hover:bg-slate-100 text-sm flex items-center gap-2 cursor-pointer text-slate-700"
                        >
                          <Users className="w-4 h-4 text-emerald-700" />
                          <span>Gestión del Personal</span>
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Libro de Asistencia */}
                  <button
                    onClick={() => handleNav('reporte')}
                    className={`px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-1.5 transition cursor-pointer ${
                      currentView === 'reporte'
                        ? 'bg-white/20 text-white font-bold'
                        : 'text-white/90 hover:bg-white/10'
                    }`}
                  >
                    <FileSpreadsheet className="w-4 h-4 text-emerald-300" />
                    Libro de Asistencia
                  </button>

                  {/* Solicitudes */}
                  <button
                    onClick={() => handleNav('solicitudes')}
                    className={`px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-1.5 transition cursor-pointer ${
                      currentView === 'solicitudes'
                        ? 'bg-white/20 text-white font-bold'
                        : 'text-white/90 hover:bg-white/10'
                    }`}
                  >
                    <Inbox className="w-4 h-4 text-amber-300" />
                    Justificativos
                  </button>

                  {/* QR Station Shortcut */}
                  <button
                    onClick={() => handleNav('qr_station')}
                    className={`px-3 py-2 rounded-lg text-sm font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                      currentView === 'qr_station'
                        ? 'bg-amber-400/25 text-amber-200 font-bold'
                        : 'text-white/90 hover:bg-white/10 hover:text-white'
                    }`}
                  >
                    <QrCode className="w-4 h-4 text-amber-300" />
                    Estación QR
                  </button>

                  {/* Parámetros */}
                  <button
                    onClick={() => handleNav('configuracion')}
                    className={`px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-1.5 transition cursor-pointer ${
                      currentView === 'configuracion'
                        ? 'bg-white/15 text-white font-semibold'
                        : 'text-white/90 hover:bg-white/10'
                    }`}
                  >
                    <Settings className="w-4 h-4 text-emerald-300" />
                    Parámetros
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => handleNav('personal')}
                    className={`px-3.5 py-2 rounded-lg text-sm font-semibold flex items-center gap-2 transition cursor-pointer ${
                      currentView === 'personal'
                        ? 'bg-white/20 text-white font-bold'
                        : 'text-white/90 hover:bg-white/10'
                    }`}
                  >
                    <UserCheck className="w-4 h-4 text-amber-300" />
                    Mi asistencia
                  </button>
                  <button
                    onClick={() => handleNav('personal_horario')}
                    className={`px-3.5 py-2 rounded-lg text-sm font-semibold flex items-center gap-2 transition cursor-pointer ${
                      currentView === 'personal_horario'
                        ? 'bg-white/20 text-white font-bold'
                        : 'text-white/90 hover:bg-white/10'
                    }`}
                  >
                    <CalendarRange className="w-4 h-4 text-emerald-300" />
                    Mis clases y horario
                  </button>
                </>
              )}
            </nav>

            {/* Right section: Thesis presentation tools, Color changer, User badge, PWA install */}
            <div className="flex items-center gap-2">
              {/* Theme Color Button */}
              <button
                onClick={() => setThemeModalOpen(true)}
                className="px-2.5 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-white flex items-center gap-1.5 text-xs font-bold border border-white/20 transition cursor-pointer"
                title="Personalizar color institucional en tiempo real"
              >
                <Palette className="w-3.5 h-3.5 text-amber-300" />
                <span className="hidden sm:inline">Colores</span>
              </button>

              <PWAInstallButton />

              {/* Institutional User Account Dropdown */}
              <div className="relative">
                <button
                  onClick={() => toggleDropdown('userSwitcher')}
                  className="bg-white/15 hover:bg-white/25 text-white px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-2 border border-white/20 transition cursor-pointer"
                  title="Cuenta activa"
                >
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  <span className="hidden sm:inline font-bold">
                    {currentUser?.nombre} {currentUser?.apellido}
                  </span>
                  <span className="bg-white/20 text-white text-[10px] px-1.5 py-0.5 rounded font-extrabold uppercase">
                    {currentUser?.rol}
                  </span>
                  <ChevronDown className="w-3 h-3 text-white/70" />
                </button>

                {openDropdown === 'userSwitcher' && (
                  <div className="absolute right-0 mt-2 w-72 bg-white rounded-2xl shadow-2xl py-2 border border-slate-200 text-slate-800 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                    <div className="px-4 py-3 border-b border-slate-100 bg-slate-50">
                      <div className="font-bold text-slate-900 text-sm">
                        {currentUser?.nombre} {currentUser?.apellido}
                      </div>
                      <div className="text-xs text-slate-500 font-mono truncate">{currentUser?.correo}</div>
                      <div className="mt-1.5 flex items-center gap-1.5">
                        <span className="text-[10px] px-2 py-0.5 rounded-full font-bold uppercase bg-emerald-100 text-emerald-800 border border-emerald-200">
                          {currentUser?.rol}
                        </span>
                        {currentUser?.departamento && (
                          <span className="text-[11px] text-slate-500 font-medium">
                            {currentUser?.departamento}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="py-1">
                      {currentUser?.rol === 'directivo' ? (
                        <button
                          onClick={() => handleNav('director')}
                          className="w-full text-left px-4 py-2 hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-2 cursor-pointer"
                        >
                          <Gauge className="w-4 h-4 text-emerald-600" />
                          Panel Directivo
                        </button>
                      ) : (
                        <button
                          onClick={() => handleNav('personal')}
                          className="w-full text-left px-4 py-2 hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-2 cursor-pointer"
                        >
                          <UserCheck className="w-4 h-4 text-emerald-600" />
                          Mi Asistencia y Carnet
                        </button>
                      )}

                      <button
                        onClick={() => {
                          setOpenDropdown(null);
                          logout();
                        }}
                        className="w-full text-left px-4 py-2 hover:bg-red-50 text-xs font-bold text-red-600 flex items-center gap-2 cursor-pointer border-t border-slate-100 mt-1"
                      >
                        <LogOut className="w-4 h-4 text-red-500" />
                        Cerrar Sesión Institucional
                      </button>
                    </div>

                    {/* Change Account Quick Select */}
                    <div className="border-t border-slate-100 px-3 py-2 bg-slate-50/70">
                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                        Cambiar de Usuario:
                      </div>
                      <div className="max-h-40 overflow-y-auto space-y-1">
                        {users.map(u => (
                          <button
                            key={u.id}
                            onClick={() => {
                              switchUser(u.id);
                              setOpenDropdown(null);
                              if (u.rol === 'directivo' && currentView.startsWith('personal')) {
                                onNavigate('director');
                              } else if (u.rol !== 'directivo' && currentView === 'director') {
                                onNavigate('personal');
                              }
                            }}
                            className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs flex items-center justify-between transition cursor-pointer ${
                              u.id === currentUser?.id ? 'bg-emerald-50 text-emerald-900 font-bold' : 'hover:bg-slate-100 text-slate-700'
                            }`}
                          >
                            <span className="truncate">{u.nombre} {u.apellido}</span>
                            <span className="text-[9px] px-1.5 py-0.5 rounded uppercase font-semibold text-slate-500 bg-slate-200">
                              {u.rol}
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Logout Button */}
              <button
                onClick={logout}
                className="p-2 rounded-lg text-white/80 hover:text-amber-300 hover:bg-white/10 transition cursor-pointer"
                title="Cerrar sesión"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Theme Customizer Modal */}
      <ThemeCustomizerModal
        isOpen={themeModalOpen}
        onClose={() => setThemeModalOpen(false)}
      />
    </>
  );
};
