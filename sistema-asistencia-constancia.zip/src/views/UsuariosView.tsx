import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { useApp } from '../context/AppContext';
import { Usuario, RolUsuario } from '../types';
import {
  Users,
  UserPlus,
  Edit,
  Trash2,
  Mail,
  Phone,
  Calendar,
  Clock,
  Building2,
  CheckCircle2,
  X,
  Search,
  Key,
  Eye,
  EyeOff,
  Copy,
  Check,
  QrCode,
  Download,
  Printer,
  Sparkles,
  Lock,
  RefreshCw
} from 'lucide-react';

export const UsuariosView: React.FC = () => {
  const { users, crearUsuario, editarUsuario, cambiarPasswordUsuario, eliminarUsuario, primaryColor } = useApp();

  const [searchTerm, setSearchTerm] = useState<string>('');
  const [roleFilter, setRoleFilter] = useState<string>('todos');

  // New User Form State
  const [nombre, setNombre] = useState('');
  const [apellido, setApellido] = useState('');
  const [correo, setCorreo] = useState('');
  const [password, setPassword] = useState('12345678');
  const [showPassword, setShowPassword] = useState(true);
  const [telefono, setTelefono] = useState('');
  const [fechaNacimiento, setFechaNacimiento] = useState('');
  const [rol, setRol] = useState<RolUsuario>('personal');
  const [departamento, setDepartamento] = useState('');
  const [horaEntrada, setHoraEntrada] = useState('07:30');
  const [horaSalida, setHoraSalida] = useState('15:30');

  // Modals & Popups State
  const [createdCredentialsModal, setCreatedCredentialsModal] = useState<{
    nombre: string;
    correo: string;
    password: string;
  } | null>(null);

  const [passwordChangeUser, setPasswordChangeUser] = useState<Usuario | null>(null);
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(true);

  const [badgeModalUser, setBadgeModalUser] = useState<Usuario | null>(null);
  const [badgeQRUrl, setBadgeQRUrl] = useState<string>('');

  const [userToDelete, setUserToDelete] = useState<Usuario | null>(null);

  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [revealedPasswords, setRevealedPasswords] = useState<Record<number, boolean>>({});

  // Edit Modal State
  const [editingUser, setEditingUser] = useState<Usuario | null>(null);
  const [editForm, setEditForm] = useState({
    nombre: '',
    apellido: '',
    telefono: '',
    password: '',
    rol: 'personal' as RolUsuario,
    departamento: '',
    hora_entrada: '07:30',
    hora_salida: '15:30',
  });

  const staffList = users.filter(u => u.rol !== 'directivo');

  const filteredStaff = staffList.filter(u => {
    if (roleFilter !== 'todos' && u.rol !== roleFilter) return false;
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      const full = `${u.nombre} ${u.apellido}`.toLowerCase();
      const mail = u.correo.toLowerCase();
      const dept = (u.departamento || '').toLowerCase();
      return full.includes(term) || mail.includes(term) || dept.includes(term);
    }
    return true;
  });

  // Generate QR for staff badge modal
  useEffect(() => {
    if (badgeModalUser) {
      const payload = JSON.stringify({
        sistema: 'U.E. La Constancia',
        tipo: 'CARNET_FUNCIONARIO',
        id: badgeModalUser.id,
        nombre: `${badgeModalUser.nombre} ${badgeModalUser.apellido}`,
        correo: badgeModalUser.correo,
        rol: badgeModalUser.rol,
        departamento: badgeModalUser.departamento || 'General',
        validado: true
      });

      QRCode.toDataURL(payload, {
        width: 320,
        margin: 2,
        color: {
          dark: primaryColor || '#0C5528',
          light: '#FFFFFF'
        },
        errorCorrectionLevel: 'H'
      }).then(url => {
        setBadgeQRUrl(url);
      }).catch(err => console.error(err));
    } else {
      setBadgeQRUrl('');
    }
  }, [badgeModalUser, primaryColor]);

  const generateRandomPassword = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
    let pass = 'Constancia';
    for (let i = 0; i < 4; i++) {
      pass += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    pass += '!';
    setPassword(pass);
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nombre.trim() || !apellido.trim() || !correo.trim()) return;

    const assignedPassword = password.trim() || '12345678';

    const res = crearUsuario({
      nombre: nombre.trim(),
      apellido: apellido.trim(),
      correo: correo.trim(),
      password: assignedPassword,
      telefono: telefono.trim() || undefined,
      fecha_nacimiento: fechaNacimiento || undefined,
      rol,
      departamento: departamento.trim() || undefined,
      hora_entrada: horaEntrada,
      hora_salida: horaSalida,
      limite_permisos: 3,
    });

    if (res.ok) {
      // Show credentials modal so the admin/user immediately has the exact password
      setCreatedCredentialsModal({
        nombre: `${nombre.trim()} ${apellido.trim()}`,
        correo: correo.trim(),
        password: assignedPassword,
      });

      setNombre('');
      setApellido('');
      setCorreo('');
      setPassword('12345678');
      setTelefono('');
      setFechaNacimiento('');
      setDepartamento('');
    }
  };

  const openEditModal = (u: Usuario) => {
    setEditingUser(u);
    setEditForm({
      nombre: u.nombre,
      apellido: u.apellido,
      telefono: u.telefono || '',
      password: u.password || '12345678',
      rol: u.rol,
      departamento: u.departamento || '',
      hora_entrada: u.hora_entrada || '07:30',
      hora_salida: u.hora_salida || '15:30',
    });
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    editarUsuario(editingUser.id, {
      nombre: editForm.nombre,
      apellido: editForm.apellido,
      telefono: editForm.telefono || undefined,
      password: editForm.password.trim() || editingUser.password || '12345678',
      rol: editForm.rol,
      departamento: editForm.departamento || undefined,
      hora_entrada: editForm.hora_entrada,
      hora_salida: editForm.hora_salida,
    });
    setEditingUser(null);
  };

  const openPasswordChangeModal = (u: Usuario) => {
    setPasswordChangeUser(u);
    setNewPasswordInput(u.password || '12345678');
    setShowNewPassword(true);
  };

  const handleSavePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (!passwordChangeUser || !newPasswordInput.trim()) return;
    cambiarPasswordUsuario(passwordChangeUser.id, newPasswordInput.trim());
    setPasswordChangeUser(null);
  };

  const togglePasswordReveal = (id: number) => {
    setRevealedPasswords(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="pb-2 border-b border-slate-200">
        <h1 className="text-2xl font-extrabold text-slate-800 tracking-tight flex items-center gap-2">
          <Users className="w-6 h-6 text-[#0C5528]" />
          Gestión del Talento Humano
        </h1>
        <p className="text-xs text-slate-500 font-medium">
          Registro administrativo de fichas de personal, claves de acceso y carnets QR oficiales
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Form: Incorporar Nuevo Funcionario (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-3xl border-l-4 border-l-emerald-600 border border-slate-100 shadow-sm p-6 space-y-4">
          <div className="pb-2 border-b border-slate-100">
            <h2 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
              <UserPlus className="w-4 h-4 text-emerald-600" />
              Incorporar Nuevo Funcionario
            </h2>
            <p className="text-xs text-slate-400">
              Registra los datos y asigna o genera su clave de acceso
            </p>
          </div>

          <form onSubmit={handleCreate} className="space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-bold text-slate-600 mb-1">Nombres</label>
                <input
                  type="text"
                  value={nombre}
                  onChange={e => setNombre(e.target.value)}
                  placeholder="Ej. Jose Miguel"
                  required
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-600 mb-1">Apellidos</label>
                <input
                  type="text"
                  value={apellido}
                  onChange={e => setApellido(e.target.value)}
                  placeholder="Ej. Jewsiejew Paez"
                  required
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-600 mb-1">Correo Electrónico Institucional / Personal</label>
              <input
                type="email"
                value={correo}
                onChange={e => setCorreo(e.target.value)}
                placeholder="ejemplo@correo.com"
                required
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none font-mono text-slate-800"
              />
            </div>

            {/* Password generation field */}
            <div className="p-3 bg-amber-50/70 border border-amber-200/80 rounded-2xl space-y-2">
              <div className="flex items-center justify-between">
                <label className="block font-bold text-amber-950 flex items-center gap-1.5">
                  <Key className="w-3.5 h-3.5 text-amber-700" />
                  Contraseña de Acceso
                </label>
                <button
                  type="button"
                  onClick={generateRandomPassword}
                  className="text-[11px] font-bold text-amber-800 hover:text-amber-950 flex items-center gap-1 cursor-pointer transition"
                  title="Generar contraseña aleatoria segura"
                >
                  <RefreshCw className="w-3 h-3 text-amber-700" /> Generar Otra
                </button>
              </div>

              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="Escriba o genere una contraseña"
                  required
                  className="w-full p-2 pr-10 bg-white border border-amber-300 rounded-xl font-mono text-slate-800 font-bold focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 cursor-pointer p-1"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-[10px] text-amber-800">
                Esta es la clave para iniciar sesión. Puedes escribir cualquier clave sencilla (ej. <code className="font-bold">12345678</code> o <code className="font-bold">admin123</code>).
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-bold text-slate-600 mb-1">Teléfono</label>
                <input
                  type="text"
                  value={telefono}
                  onChange={e => setTelefono(e.target.value)}
                  placeholder="0412-580-3864"
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-600 mb-1">F. Nacimiento</label>
                <input
                  type="date"
                  value={fechaNacimiento}
                  onChange={e => setFechaNacimiento(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-600 mb-1">Rol Estructural / Cargo</label>
              <select
                value={rol}
                onChange={e => setRol(e.target.value as RolUsuario)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none font-semibold text-slate-800"
              >
                <option value="administrativo">Personal Administrativo</option>
                <option value="personal">Personal Docente (Profesor)</option>
                <option value="obrero">Personal Obrero / Operativo</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-600 mb-1">Departamento / Función</label>
              <input
                type="text"
                value={departamento}
                onChange={e => setDepartamento(e.target.value)}
                placeholder="Ej. Desarrollador, Control de Estudios, Ciencias"
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-bold text-slate-600 mb-1">Hora Entrada</label>
                <input
                  type="time"
                  value={horaEntrada}
                  onChange={e => setHoraEntrada(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none font-mono"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-600 mb-1">Hora Salida</label>
                <input
                  type="time"
                  value={horaSalida}
                  onChange={e => setHoraSalida(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none font-mono"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-md transition cursor-pointer flex items-center justify-center gap-1.5 mt-3"
            >
              <Key className="w-4 h-4 text-amber-300" />
              Registrar Funcionario y Guardar Clave
            </button>
          </form>
        </div>

        {/* Table: Nómina Activa de Personal (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-100 shadow-sm p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-700" />
                Nómina Activa de Personal
              </h2>
              <span className="text-xs text-slate-400">
                {filteredStaff.length} empleado(s) registrado(s)
              </span>
            </div>

            <div className="flex items-center gap-2">
              <select
                value={roleFilter}
                onChange={e => setRoleFilter(e.target.value)}
                className="text-xs p-1.5 bg-slate-50 border border-slate-200 rounded-xl"
              >
                <option value="todos">Todos los Roles</option>
                <option value="administrativo">Administrativos</option>
                <option value="personal">Docentes</option>
                <option value="obrero">Obreros</option>
              </select>
            </div>
          </div>

          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Buscar por nombre, correo o departamento..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-700 focus:outline-none"
            />
          </div>

          <div className="overflow-x-auto text-xs">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] border-b border-slate-100">
                  <th className="py-2.5 px-3">Funcionario</th>
                  <th className="py-2.5 px-3">Clave de Acceso</th>
                  <th className="py-2.5 px-3">Rol & Depto</th>
                  <th className="py-2.5 px-3">Jornada</th>
                  <th className="py-2.5 px-3 text-right">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredStaff.map(p => {
                  const isRevealed = !!revealedPasswords[p.id];
                  const displayPass = p.password || '12345678';
                  return (
                    <tr key={p.id} className="hover:bg-slate-50">
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900">
                          {p.apellido}, {p.nombre}
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono">{p.correo}</div>
                        {p.telefono && (
                          <div className="text-[10px] text-slate-500 font-mono mt-0.5">{p.telefono}</div>
                        )}
                      </td>
                      <td className="py-3 px-3">
                        <div className="inline-flex items-center gap-1.5 bg-slate-100/80 px-2 py-1 rounded-lg border border-slate-200 font-mono text-[11px]">
                          <span className="font-bold text-slate-800">
                            {isRevealed ? displayPass : '••••••••'}
                          </span>
                          <button
                            type="button"
                            onClick={() => togglePasswordReveal(p.id)}
                            className="text-slate-400 hover:text-slate-700 p-0.5 cursor-pointer"
                            title={isRevealed ? 'Ocultar clave' : 'Ver clave'}
                          >
                            {isRevealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                          </button>
                          <button
                            type="button"
                            onClick={() => copyToClipboard(displayPass, `pass-${p.id}`)}
                            className="text-slate-400 hover:text-emerald-700 p-0.5 cursor-pointer"
                            title="Copiar contraseña"
                          >
                            {copiedId === `pass-${p.id}` ? (
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      </td>
                      <td className="py-3 px-3">
                        <span
                          className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                            p.rol === 'personal'
                              ? 'bg-emerald-100 text-emerald-800'
                              : p.rol === 'administrativo'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {p.rol}
                        </span>
                        {p.departamento && (
                          <div className="text-[11px] text-slate-500 mt-0.5">{p.departamento}</div>
                        )}
                      </td>
                      <td className="py-3 px-3 font-mono text-slate-600 whitespace-nowrap">
                        {p.hora_entrada || '07:30'} - {p.hora_salida || '15:30'}
                      </td>
                      <td className="py-3 px-3 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1">
                          {/* Change / Reset Password button */}
                          <button
                            onClick={() => openPasswordChangeModal(p)}
                            className="p-1.5 text-amber-700 hover:bg-amber-50 rounded-lg transition cursor-pointer"
                            title="Cambiar contraseña de este usuario"
                          >
                            <Key className="w-4 h-4" />
                          </button>

                          {/* Staff QR Badge */}
                          <button
                            onClick={() => setBadgeModalUser(p)}
                            className="p-1.5 text-emerald-700 hover:bg-emerald-50 rounded-lg transition cursor-pointer"
                            title="Ver Carnet QR Oficial del Funcionario"
                          >
                            <QrCode className="w-4 h-4" />
                          </button>

                          {/* Edit button */}
                          <button
                            onClick={() => openEditModal(p)}
                            className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition cursor-pointer"
                            title="Editar funcionario"
                          >
                            <Edit className="w-4 h-4" />
                          </button>

                          {/* Delete button */}
                          <button
                            type="button"
                            onClick={() => setUserToDelete(p)}
                            className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition cursor-pointer"
                            title="Eliminar funcionario"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Modal 1: Credenciales Generadas Exitosamente */}
      {createdCredentialsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
            <div className="bg-gradient-to-r from-emerald-800 to-emerald-700 text-white px-6 py-5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5 text-amber-300" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base leading-tight">
                    ¡Funcionario Registrado con Éxito!
                  </h3>
                  <p className="text-[11px] text-emerald-200 font-medium">
                    Credenciales de acceso generadas
                  </p>
                </div>
              </div>
              <button
                onClick={() => setCreatedCredentialsModal(null)}
                className="text-white/80 hover:text-white text-xl font-bold cursor-pointer"
              >
                &times;
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div className="p-4 bg-emerald-50/80 border border-emerald-200 rounded-2xl space-y-3">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800">
                    Nombre del Funcionario
                  </span>
                  <div className="font-extrabold text-sm text-slate-800">
                    {createdCredentialsModal.nombre}
                  </div>
                </div>

                <div className="pt-2 border-t border-emerald-100 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800">
                      Usuario / Correo
                    </span>
                    <div className="font-mono font-bold text-slate-800 text-xs">
                      {createdCredentialsModal.correo}
                    </div>
                  </div>
                  <button
                    onClick={() => copyToClipboard(createdCredentialsModal.correo, 'modal-email')}
                    className="p-1.5 text-emerald-700 hover:bg-emerald-100 rounded-lg cursor-pointer transition"
                    title="Copiar correo"
                  >
                    {copiedId === 'modal-email' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>

                <div className="pt-2 border-t border-emerald-100 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800">
                      Contraseña Asignada
                    </span>
                    <div className="font-mono font-extrabold text-amber-900 text-sm bg-white px-2.5 py-1 rounded-lg border border-amber-300 inline-block mt-0.5">
                      {createdCredentialsModal.password}
                    </div>
                  </div>
                  <button
                    onClick={() => copyToClipboard(createdCredentialsModal.password, 'modal-pass')}
                    className="p-1.5 text-amber-700 hover:bg-amber-100 rounded-lg cursor-pointer transition"
                    title="Copiar contraseña"
                  >
                    {copiedId === 'modal-pass' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const fullText = `Acceso U.E. La Constancia\nFuncionario: ${createdCredentialsModal.nombre}\nUsuario: ${createdCredentialsModal.correo}\nContraseña: ${createdCredentialsModal.password}`;
                    copyToClipboard(fullText, 'modal-all');
                  }}
                  className="flex-1 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition shadow-sm"
                >
                  {copiedId === 'modal-all' ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-400" /> ¡Copiado al Portapapeles!
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-amber-300" /> Copiar Todas las Credenciales
                    </>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => setCreatedCredentialsModal(null)}
                  className="px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl cursor-pointer transition"
                >
                  Aceptar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal 2: Cambiar Contraseña Directamente */}
      {passwordChangeUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-3xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-200">
            <div className="bg-gradient-to-r from-amber-600 to-amber-700 text-white px-5 py-4 flex items-center justify-between">
              <h3 className="font-bold text-sm flex items-center gap-2">
                <Key className="w-4 h-4 text-amber-200" />
                Cambiar Contraseña
              </h3>
              <button
                onClick={() => setPasswordChangeUser(null)}
                className="text-white/80 hover:text-white text-xl font-bold cursor-pointer"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleSavePasswordChange} className="p-6 space-y-4 text-xs">
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase">Funcionario</span>
                <div className="font-bold text-slate-800 text-sm">
                  {passwordChangeUser.apellido}, {passwordChangeUser.nombre}
                </div>
                <div className="text-[11px] text-slate-500 font-mono">{passwordChangeUser.correo}</div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Nueva Contraseña de Acceso
                </label>
                <div className="relative">
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    value={newPasswordInput}
                    onChange={e => setNewPasswordInput(e.target.value)}
                    required
                    placeholder="Escriba la nueva contraseña"
                    className="w-full p-2.5 pr-10 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold text-slate-800 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 p-1 cursor-pointer"
                  >
                    {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <div className="flex gap-2 mt-2">
                  <button
                    type="button"
                    onClick={() => setNewPasswordInput('admin123')}
                    className="px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded-lg text-[10px] font-bold text-slate-700 cursor-pointer"
                  >
                    admin123
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewPasswordInput('12345678')}
                    className="px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded-lg text-[10px] font-bold text-slate-700 cursor-pointer"
                  >
                    12345678
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewPasswordInput(`Constancia${Math.floor(1000 + Math.random() * 9000)}!`)}
                    className="px-2 py-1 bg-amber-100 hover:bg-amber-200 rounded-lg text-[10px] font-bold text-amber-800 cursor-pointer"
                  >
                    🎲 Aleatoria
                  </button>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setPasswordChangeUser(null)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 rounded-xl font-bold cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold cursor-pointer shadow-sm"
                >
                  Guardar Contraseña
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 3: Carnet QR Oficial del Funcionario */}
      {badgeModalUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-3xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-200">
            <div className="bg-[#0C5528] text-white px-5 py-4 flex items-center justify-between">
              <h3 className="font-bold text-sm flex items-center gap-2">
                <QrCode className="w-4 h-4 text-amber-300" />
                Carnet QR Digital del Funcionario
              </h3>
              <button
                onClick={() => setBadgeModalUser(null)}
                className="text-white/80 hover:text-white text-xl font-bold cursor-pointer"
              >
                &times;
              </button>
            </div>

            <div className="p-6 text-center space-y-4 text-xs">
              {/* Badge Visual Card */}
              <div className="p-5 bg-gradient-to-b from-slate-50 to-emerald-50/50 rounded-2xl border-2 border-emerald-600/30 shadow-md">
                <div className="w-12 h-12 rounded-full bg-white p-1 border border-amber-400 mx-auto mb-2 overflow-hidden shadow-sm">
                  <img
                    src="/img/logo.png"
                    alt="Logo La Constancia"
                    className="w-full h-full object-contain"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src = '/img/logoo.png';
                    }}
                  />
                </div>
                <div className="font-extrabold text-slate-900 text-sm">
                  {badgeModalUser.nombre} {badgeModalUser.apellido}
                </div>
                <div className="text-[11px] font-mono text-emerald-800 font-bold uppercase mt-0.5">
                  {badgeModalUser.rol} · {badgeModalUser.departamento || 'Institucional'}
                </div>
                <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                  {badgeModalUser.correo}
                </div>

                {/* Real QR matrix */}
                <div className="my-4 bg-white p-3 rounded-2xl inline-block shadow-inner border border-slate-200">
                  {badgeQRUrl ? (
                    <img
                      src={badgeQRUrl}
                      alt="Carnet QR"
                      className="w-44 h-44 mx-auto object-contain"
                    />
                  ) : (
                    <div className="w-44 h-44 flex items-center justify-center text-slate-400">
                      Generando QR...
                    </div>
                  )}
                </div>

                <div className="text-[10px] text-slate-500 font-medium">
                  U.E. "La Constancia" · Válido para Registro en Portería
                </div>
              </div>

              <div className="flex gap-2">
                {badgeQRUrl && (
                  <a
                    href={badgeQRUrl}
                    download={`Carnet_QR_${badgeModalUser.apellido}_${badgeModalUser.nombre}.png`}
                    className="flex-1 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl flex items-center justify-center gap-1.5 transition cursor-pointer shadow-sm"
                  >
                    <Download className="w-3.5 h-3.5 text-amber-300" /> Descargar QR
                  </a>
                )}
                <button
                  onClick={() => window.print()}
                  className="px-4 py-2.5 border border-slate-200 text-slate-700 hover:bg-slate-50 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition"
                >
                  <Printer className="w-3.5 h-3.5" /> Imprimir
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal 4: Editar Funcionario */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
            <div className="bg-[#0C5528] text-white px-6 py-4 flex items-center justify-between">
              <h3 className="font-bold text-sm flex items-center gap-2">
                <Edit className="w-4 h-4 text-amber-300" />
                Editar Funcionario
              </h3>
              <button
                onClick={() => setEditingUser(null)}
                className="text-white/80 hover:text-white text-xl font-bold cursor-pointer"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="p-6 space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-600 mb-1">Nombre</label>
                  <input
                    type="text"
                    value={editForm.nombre}
                    onChange={e => setEditForm(prev => ({ ...prev, nombre: e.target.value }))}
                    required
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-600 mb-1">Apellido</label>
                  <input
                    type="text"
                    value={editForm.apellido}
                    onChange={e => setEditForm(prev => ({ ...prev, apellido: e.target.value }))}
                    required
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              {/* Edit Password field */}
              <div>
                <label className="block font-bold text-slate-700 mb-1 flex items-center justify-between">
                  <span>Contraseña de Acceso</span>
                  <span className="text-[10px] text-slate-400 font-normal">Puede modificarla aquí</span>
                </label>
                <input
                  type="text"
                  value={editForm.password}
                  onChange={e => setEditForm(prev => ({ ...prev, password: e.target.value }))}
                  required
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold text-slate-800"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-600 mb-1">Teléfono</label>
                <input
                  type="text"
                  value={editForm.telefono}
                  onChange={e => setEditForm(prev => ({ ...prev, telefono: e.target.value }))}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-600 mb-1">Rol Estructural</label>
                <select
                  value={editForm.rol}
                  onChange={e => setEditForm(prev => ({ ...prev, rol: e.target.value as any }))}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                >
                  <option value="administrativo">Personal Administrativo</option>
                  <option value="personal">Personal Docente (Profesor)</option>
                  <option value="obrero">Personal Obrero / Operativo</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-600 mb-1">Departamento</label>
                <input
                  type="text"
                  value={editForm.departamento}
                  onChange={e => setEditForm(prev => ({ ...prev, departamento: e.target.value }))}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-600 mb-1">Hora Entrada</label>
                  <input
                    type="time"
                    value={editForm.hora_entrada}
                    onChange={e => setEditForm(prev => ({ ...prev, hora_entrada: e.target.value }))}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-600 mb-1">Hora Salida</label>
                  <input
                    type="time"
                    value={editForm.hora_salida}
                    onChange={e => setEditForm(prev => ({ ...prev, hora_salida: e.target.value }))}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => {
                    const target = editingUser;
                    setEditingUser(null);
                    setUserToDelete(target);
                  }}
                  className="px-3 py-2 text-red-600 hover:bg-red-50 rounded-xl font-bold text-xs flex items-center gap-1.5 cursor-pointer transition"
                >
                  <Trash2 className="w-4 h-4" />
                  Eliminar Funcionario
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingUser(null)}
                    className="px-4 py-2 border border-slate-200 text-slate-600 rounded-xl font-bold cursor-pointer hover:bg-slate-50 transition"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-[#0C5528] hover:bg-[#072e19] text-white rounded-xl font-bold cursor-pointer transition shadow-sm"
                  >
                    Guardar Cambios
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 5: Confirmación de Eliminación In-App (Sin window.confirm) */}
      {userToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-3xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-200 p-6 text-center space-y-4">
            <div className="w-14 h-14 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <Trash2 className="w-7 h-7" />
            </div>

            <div>
              <h3 className="text-base font-extrabold text-slate-900">
                ¿Eliminar Funcionario?
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                ¿Estás seguro de que deseas eliminar a <strong>{userToDelete.nombre} {userToDelete.apellido}</strong> de la nómina institucional?
              </p>
              <div className="text-[11px] font-mono text-slate-400 mt-0.5">
                {userToDelete.correo}
              </div>
            </div>

            <div className="p-3 bg-red-50 border border-red-200 rounded-2xl text-left text-[11px] text-red-800">
              Esta acción dará de baja definitiva a este personal y removerá sus credenciales de acceso al sistema.
            </div>

            <div className="flex items-center justify-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => setUserToDelete(null)}
                className="flex-1 py-2.5 px-3 border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  eliminarUsuario(userToDelete.id);
                  setUserToDelete(null);
                }}
                className="flex-1 py-2.5 px-3 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer"
              >
                Sí, Eliminar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
