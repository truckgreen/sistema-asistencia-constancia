import React, { useState, useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import { Html5Qrcode } from 'html5-qrcode';
import { useApp } from '../context/AppContext';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import {
  QrCode,
  Camera,
  CameraOff,
  Scan,
  Upload,
  Clock,
  Wifi,
  WifiOff,
  UserCheck,
  CheckCircle2,
  AlertCircle,
  Database,
  RefreshCw,
  HardDriveDownload,
  ArrowLeft,
  Printer,
  ShieldCheck,
  ShieldAlert,
  Download,
  Smartphone,
  ScanLine,
  Palette,
  Volume2
} from 'lucide-react';

interface OfflineScanRecord {
  id: number;
  usuario_id: number;
  nombre_completo: string;
  timestamp: string;
  hora_str: string;
}

interface QRStationViewProps {
  onNavigate: (view: any) => void;
}

const OFFLINE_QUEUE_KEY = 'constancia_porteria_offline_queue_v3';

export const QRStationView: React.FC<QRStationViewProps> = ({ onNavigate }) => {
  const { users, registrarAsistencia, primaryColor } = useApp();
  const realIsOnline = useOnlineStatus();

  // Simulated offline toggle for testing
  const [forceSimulatedOffline, setForceSimulatedOffline] = useState(false);
  const effectiveOnline = realIsOnline && !forceSimulatedOffline;

  // Selected view tab: 'scanner' (live camera), 'poster' (station/carnet QR generator), 'simulator'
  const [activeTab, setActiveTab] = useState<'scanner' | 'poster' | 'simulator'>('scanner');

  // Time state
  const [currentTime, setCurrentTime] = useState<string>('');

  // Results & Feedback State
  const [scanResult, setScanResult] = useState<{
    ok: boolean;
    message: string;
    funcionario?: string;
    cargo?: string;
    estado?: string;
    hora?: string;
  } | null>(null);

  // Live Camera Scanner State
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const html5QrCodeRef = useRef<Html5Qrcode | null>(null);
  const lastScannedTimeRef = useRef<number>(0);
  const lastScannedPayloadRef = useRef<string>('');

  // Generator State (Station vs Personal)
  const [qrMode, setQrMode] = useState<'station' | 'personal'>('station');
  const [selectedUserToGenerate, setSelectedUserToGenerate] = useState<number>(() => users[0]?.id || 1);
  const [qrColorStyle, setQrColorStyle] = useState<'institucional' | 'negro'>('institucional');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  // Simulator Selector State
  const [selectedUserToSimulate, setSelectedUserToSimulate] = useState<number>(() => users[1]?.id || users[0]?.id || 1);

  // Offline queue state
  const [offlineQueue, setOfflineQueue] = useState<OfflineScanRecord[]>(() => {
    try {
      const saved = localStorage.getItem(OFFLINE_QUEUE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(offlineQueue));
  }, [offlineQueue]);

  // Clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true }));
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  // Audio confirmation beep using standard Web Audio API
  const playBeep = (success: boolean) => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      if (success) {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, ctx.currentTime); // A5
        osc.frequency.setValueAtTime(1174.66, ctx.currentTime + 0.1); // D6
        gain.gain.setValueAtTime(0.25, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.25);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.25);
      } else {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(260, ctx.currentTime);
        gain.gain.setValueAtTime(0.2, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.3);
      }
    } catch (e) {
      console.warn('AudioContext not allowed or not ready', e);
    }
  };

  // Generate authentic scannable QR Code for Poster / Carnet
  useEffect(() => {
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];

    let contentToEncode = '';

    if (qrMode === 'station') {
      const appOrigin = typeof window !== 'undefined' ? window.location.origin : 'https://ue-laconstancia.edu.ve';
      contentToEncode = `${appOrigin}/?accion=asistencia_porteria&institucion=la_constancia&estacion=PORT-01&fecha=${todayStr}`;
    } else {
      const targetUser = users.find(u => u.id === selectedUserToGenerate) || users[0];
      contentToEncode = JSON.stringify({
        sistema: 'U.E. La Constancia',
        tipo: 'CARNET_PERSONAL',
        id: targetUser?.id,
        funcionario: `${targetUser?.nombre} ${targetUser?.apellido}`,
        correo: targetUser?.correo,
        rol: targetUser?.rol,
        departamento: targetUser?.departamento || 'General',
        fecha: todayStr,
      });
    }

    const darkColor = qrColorStyle === 'institucional' ? (primaryColor || '#0C5528') : '#000000';

    QRCode.toDataURL(contentToEncode, {
      width: 450,
      margin: 2,
      color: {
        dark: darkColor,
        light: '#FFFFFF',
      },
      errorCorrectionLevel: 'H',
    })
      .then(url => {
        setQrDataUrl(url);
      })
      .catch(err => {
        console.error('Error generando QR:', err);
      });
  }, [qrMode, selectedUserToGenerate, qrColorStyle, primaryColor, users]);

  // Decode & Process Detected QR String
  const processDecodedQr = (rawText: string) => {
    const now = Date.now();
    // Anti-debounce: Prevent duplicate triggers within 2.5 seconds for same payload
    if (rawText === lastScannedPayloadRef.current && now - lastScannedTimeRef.current < 2500) {
      return;
    }
    lastScannedPayloadRef.current = rawText;
    lastScannedTimeRef.current = now;

    let targetUserId: number | null = null;

    try {
      // 1. Try parsing JSON
      const parsed = JSON.parse(rawText);
      if (parsed.id) targetUserId = Number(parsed.id);
      else if (parsed.usuario_id) targetUserId = Number(parsed.usuario_id);
    } catch {
      // 2. Try URL query param ?usuario_id=X or ?id=X
      if (rawText.includes('usuario_id=')) {
        const m = rawText.match(/usuario_id=(\d+)/);
        if (m) targetUserId = Number(m[1]);
      } else if (rawText.includes('id=')) {
        const m = rawText.match(/id=(\d+)/);
        if (m) targetUserId = Number(m[1]);
      } else if (!isNaN(Number(rawText.trim()))) {
        // Plain ID number
        targetUserId = Number(rawText.trim());
      } else {
        // Check if email
        const found = users.find(u => u.correo.toLowerCase() === rawText.trim().toLowerCase());
        if (found) targetUserId = found.id;
      }
    }

    // Default fallback if scanning station QR directly
    if (!targetUserId && rawText.includes('asistencia_porteria')) {
      targetUserId = selectedUserToSimulate || users[0]?.id || 1;
    }

    if (!targetUserId) {
      playBeep(false);
      setScanResult({
        ok: false,
        message: 'Código QR no reconocido. Formato no compatible con la U.E. "La Constancia".',
      });
      return;
    }

    const targetUser = users.find(u => u.id === targetUserId);
    if (!targetUser) {
      playBeep(false);
      setScanResult({
        ok: false,
        message: `Funcionario ID #${targetUserId} no encontrado en la nómina del plantel.`,
      });
      return;
    }

    const fullName = `${targetUser.nombre} ${targetUser.apellido}`;

    // Handle offline vs online
    if (!effectiveOnline) {
      const hora_str = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
      const record: OfflineScanRecord = {
        id: Date.now(),
        usuario_id: targetUser.id,
        nombre_completo: fullName,
        timestamp: new Date().toISOString(),
        hora_str,
      };

      setOfflineQueue(prev => [record, ...prev]);
      playBeep(true);
      setScanResult({
        ok: true,
        message: `[MODO OFFLINE] Marcaje registrado en memoria de portería.`,
        funcionario: fullName,
        cargo: `${targetUser.rol.toUpperCase()} · ${targetUser.departamento || 'General'}`,
        estado: 'Guardado Localmente',
        hora: hora_str,
      });
      return;
    }

    // Online registration
    const res = registrarAsistencia(targetUser.id);
    playBeep(res.ok);
    setScanResult({
      ok: res.ok,
      message: res.message,
      funcionario: fullName,
      cargo: `${targetUser.rol.toUpperCase()} · ${targetUser.departamento || 'General'}`,
      estado: res.estado,
      hora: res.hora,
    });
  };

  // Start Live Camera QR Scanner
  const startCamera = async () => {
    setCameraError(null);
    try {
      const scanner = new Html5Qrcode('qr-camera-stream');
      html5QrCodeRef.current = scanner;

      await scanner.start(
        { facingMode: 'environment' },
        {
          fps: 15,
          qrbox: { width: 260, height: 260 },
          aspectRatio: 1.0,
        },
        (decodedText) => {
          processDecodedQr(decodedText);
        },
        () => {
          // Frame error ignore
        }
      );

      setIsCameraActive(true);
    } catch (err: any) {
      console.error('Error iniciando cámara:', err);
      setCameraError(
        'No se pudo acceder a la cámara web. Asegúrate de otorgar permisos de cámara o utiliza el escaneo de archivo/simulador.'
      );
      setIsCameraActive(false);
    }
  };

  // Stop Camera
  const stopCamera = async () => {
    if (html5QrCodeRef.current) {
      try {
        if (html5QrCodeRef.current.isScanning) {
          await html5QrCodeRef.current.stop();
        }
        await html5QrCodeRef.current.clear();
      } catch (err) {
        console.error('Error deteniendo cámara:', err);
      } finally {
        html5QrCodeRef.current = null;
        setIsCameraActive(false);
      }
    }
  };

  // Clean up camera on unmount or tab switch
  useEffect(() => {
    return () => {
      if (html5QrCodeRef.current && html5QrCodeRef.current.isScanning) {
        html5QrCodeRef.current.stop().then(() => html5QrCodeRef.current?.clear()).catch(() => {});
      }
    };
  }, []);

  // Handle switching tabs
  const handleTabSwitch = (tab: 'scanner' | 'poster' | 'simulator') => {
    if (activeTab === 'scanner' && isCameraActive) {
      stopCamera();
    }
    setActiveTab(tab);
  };

  // Handle Image File Scanning (Drag & Drop or Upload)
  const handleFileUploadScan = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const tempScanner = new Html5Qrcode('qr-temp-file-reader');
      const decodedText = await tempScanner.scanFile(file, true);
      tempScanner.clear();
      processDecodedQr(decodedText);
    } catch (err) {
      playBeep(false);
      setScanResult({
        ok: false,
        message: 'No se detectó un código QR válido en la imagen seleccionada.',
      });
    }
  };

  // Trigger simulated scan
  const handleSimulateScan = () => {
    const target = users.find(u => u.id === selectedUserToSimulate);
    if (!target) return;
    processDecodedQr(JSON.stringify({ id: target.id, funcionario: `${target.nombre} ${target.apellido}` }));
  };

  // Offline queue synchronization
  const handleSyncQueue = () => {
    if (offlineQueue.length === 0) return;

    let syncCount = 0;
    offlineQueue.forEach(item => {
      registrarAsistencia(item.usuario_id);
      syncCount++;
    });

    setOfflineQueue([]);
    playBeep(true);
    setScanResult({
      ok: true,
      message: `¡Sincronización Exitosa! Se registraron ${syncCount} marcación(es) acumuladas offline en el Libro Digital.`,
      estado: 'Sincronizado',
      hora: currentTime,
    });
  };

  const handleExportOfflineBackup = () => {
    if (offlineQueue.length === 0) return;
    const headers = ['ID', 'Funcionario', 'Hora Marcacion', 'Fecha ISO'];
    const rows = offlineQueue.map(item => [
      item.usuario_id,
      `"${item.nombre_completo}"`,
      item.hora_str,
      item.timestamp,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Respaldo_Porteria_Offline_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const activePosterUser = users.find(u => u.id === selectedUserToGenerate);

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-300">
      {/* Hidden container for file scan processing */}
      <div id="qr-temp-file-reader" className="hidden"></div>

      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-sm p-6 sm:p-8 text-center">
        {/* Header */}
        <div className="pb-4 border-b border-slate-100 mb-6">
          <div className="w-16 h-16 rounded-full bg-white p-1 border-2 border-emerald-600 shadow-md flex items-center justify-center mx-auto mb-3 overflow-hidden">
            <img
              src="/img/logo.png"
              alt="Logo U.E. La Constancia"
              className="w-full h-full object-contain"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src = '/img/logoo.png';
              }}
            />
          </div>
          <h1 className="text-2xl font-extrabold text-slate-800 tracking-tight flex items-center justify-center gap-2">
            <QrCode className="w-6 h-6 text-[#0C5528]" />
            Estación de Marcaje QR & Portería
          </h1>
          <p className="text-xs text-slate-400 font-medium mt-1">
            U.E. "La Constancia" · Control Oficial de Asistencias & Lectura Óptica en Tiempo Real
          </p>

          {/* Connection Mode Badges */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-3">
            {effectiveOnline ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                <Wifi className="w-3.5 h-3.5 text-emerald-600" /> Red Institucional Online
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300 animate-pulse">
                <WifiOff className="w-3.5 h-3.5 text-amber-700" /> Modo Portería Offline Activo
              </span>
            )}

            <button
              onClick={() => setForceSimulatedOffline(!forceSimulatedOffline)}
              className="px-2.5 py-1 text-[11px] rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600 font-semibold transition cursor-pointer"
            >
              {forceSimulatedOffline ? 'Restablecer Conexión' : 'Simular Corte de Internet'}
            </button>
          </div>
        </div>

        {/* Live Clock & Sound Indicator */}
        <div className="flex flex-wrap items-center justify-center gap-3 mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-900 text-amber-300 font-mono text-sm font-bold shadow-md">
            <Clock className="w-4 h-4 text-emerald-400" />
            <span>Hora Oficial: {currentTime || '07:30:00 AM'}</span>
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-100 border border-slate-200 text-xs font-bold text-slate-600">
            <Volume2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>Tono de confirmación activo</span>
          </div>
        </div>

        {/* Main Operational Tabs */}
        <div className="flex justify-center mb-6">
          <div className="inline-flex p-1 bg-slate-100 rounded-2xl border border-slate-200 text-xs font-bold max-w-full overflow-x-auto">
            <button
              type="button"
              onClick={() => handleTabSwitch('scanner')}
              className={`px-4 py-2 rounded-xl transition cursor-pointer flex items-center gap-2 ${
                activeTab === 'scanner'
                  ? 'bg-white text-slate-900 shadow-sm font-extrabold'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Scan className="w-4 h-4 text-emerald-600" />
              Lector Óptico de Cámara (En Vivo)
            </button>

            <button
              type="button"
              onClick={() => handleTabSwitch('poster')}
              className={`px-4 py-2 rounded-xl transition cursor-pointer flex items-center gap-2 ${
                activeTab === 'poster'
                  ? 'bg-white text-slate-900 shadow-sm font-extrabold'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Smartphone className="w-4 h-4 text-amber-600" />
              Cartel QR de la Estación
            </button>

            <button
              type="button"
              onClick={() => handleTabSwitch('simulator')}
              className={`px-4 py-2 rounded-xl transition cursor-pointer flex items-center gap-2 ${
                activeTab === 'simulator'
                  ? 'bg-white text-slate-900 shadow-sm font-extrabold'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <UserCheck className="w-4 h-4 text-blue-600" />
              Marcaje Directo de Prueba
            </button>
          </div>
        </div>

        {/* SCAN RESULT BANNER (Shared Across All Tabs) */}
        {scanResult && (
          <div
            className={`max-w-md mx-auto mb-6 p-4 rounded-2xl border text-left shadow-md animate-in fade-in slide-in-from-top-2 duration-200 ${
              scanResult.ok
                ? 'bg-emerald-50/90 border-emerald-300 text-emerald-950'
                : 'bg-red-50/90 border-red-300 text-red-950'
            }`}
          >
            <div className="flex items-start gap-3">
              {scanResult.ok ? (
                <div className="w-9 h-9 rounded-full bg-emerald-200 text-emerald-800 flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-5 h-5 text-emerald-700" />
                </div>
              ) : (
                <div className="w-9 h-9 rounded-full bg-red-200 text-red-800 flex items-center justify-center shrink-0">
                  <ShieldAlert className="w-5 h-5 text-red-700" />
                </div>
              )}

              <div className="flex-1">
                {scanResult.funcionario && (
                  <div className="font-extrabold text-sm text-slate-900 mb-0.5">
                    {scanResult.funcionario}
                  </div>
                )}
                {scanResult.cargo && (
                  <div className="text-[11px] font-semibold text-slate-600 mb-1">
                    {scanResult.cargo}
                  </div>
                )}
                <div className="text-xs font-bold">{scanResult.message}</div>
                {scanResult.hora && (
                  <div className="text-[11px] font-mono mt-1 opacity-90">
                    Estatus: <span className="font-bold uppercase">{scanResult.estado || 'Registrado'}</span> · Hora: {scanResult.hora}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* TAB 1: LIVE CAMERA QR SCANNER */}
        {activeTab === 'scanner' && (
          <div className="max-w-md mx-auto space-y-4">
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-3xl">
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
                <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                  <Camera className="w-4 h-4 text-emerald-600" />
                  Lector de Carnets por Cámara
                </span>
                {isCameraActive && (
                  <span className="inline-flex items-center gap-1 text-[10px] font-extrabold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                    Escanenado en Vivo
                  </span>
                )}
              </div>

              {/* Viewport for Camera Stream */}
              <div className="relative bg-black rounded-2xl overflow-hidden min-h-[280px] flex items-center justify-center border-2 border-slate-800 shadow-inner">
                <div id="qr-camera-stream" className="w-full h-full"></div>

                {!isCameraActive && (
                  <div className="p-6 text-center text-slate-300 space-y-3 z-10">
                    <Scan className="w-12 h-12 text-slate-500 mx-auto opacity-70" />
                    <p className="text-xs text-slate-300 font-medium">
                      Activa la cámara del dispositivo para leer los carnets QR del personal al ingresar al plantel.
                    </p>
                    <button
                      type="button"
                      onClick={startCamera}
                      className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-lg transition cursor-pointer flex items-center gap-2 mx-auto active:scale-95"
                    >
                      <Camera className="w-4 h-4 text-amber-300" />
                      Activar Cámara de Portería
                    </button>
                  </div>
                )}

                {/* Laser scan animation overlay when active */}
                {isCameraActive && (
                  <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-6">
                    <div className="border-2 border-dashed border-emerald-400/70 rounded-2xl h-full w-full relative overflow-hidden">
                      <div className="w-full h-0.5 bg-emerald-400 shadow-[0_0_12px_#34d399] absolute top-0 animate-[bounce_2s_infinite]"></div>
                    </div>
                  </div>
                )}
              </div>

              {/* Camera Error Message if any */}
              {cameraError && (
                <div className="mt-3 p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2 text-left">
                  <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                  <span>{cameraError}</span>
                </div>
              )}

              {/* Controls under camera */}
              <div className="mt-3 flex items-center justify-between gap-2">
                {isCameraActive ? (
                  <button
                    type="button"
                    onClick={stopCamera}
                    className="w-full py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <CameraOff className="w-3.5 h-3.5 text-red-400" />
                    Detener Cámara
                  </button>
                ) : (
                  <label className="w-full py-2 px-3 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 font-bold text-xs rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 shadow-sm">
                    <Upload className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Escanear archivo / captura de QR</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileUploadScan}
                      className="hidden"
                    />
                  </label>
                )}
              </div>
            </div>

            <p className="text-[11px] text-slate-400 text-center">
              Apunta el carnet del funcionario frente al visor óptico. Al detectar el código, emitirá un sonido de validación y asentará la asistencia automáticamente.
            </p>
          </div>
        )}

        {/* TAB 2: STATION / CARNET QR GENERATOR */}
        {activeTab === 'poster' && (
          <div className="space-y-4">
            {/* Sub-selector Mode */}
            <div className="flex items-center justify-center gap-2 mb-2">
              <div className="inline-flex p-1 bg-slate-100 rounded-xl border border-slate-200 text-xs">
                <button
                  type="button"
                  onClick={() => setQrMode('station')}
                  className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                    qrMode === 'station' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'
                  }`}
                >
                  QR General de Entrada (Estación PORT-01)
                </button>
                <button
                  type="button"
                  onClick={() => setQrMode('personal')}
                  className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                    qrMode === 'personal' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'
                  }`}
                >
                  Carnet QR Individual
                </button>
              </div>
            </div>

            {/* If personal mode, select user */}
            {qrMode === 'personal' && (
              <div className="max-w-xs mx-auto mb-3 text-left">
                <label className="block text-[11px] font-bold text-slate-500 mb-1">
                  Seleccionar Funcionario:
                </label>
                <select
                  value={selectedUserToGenerate}
                  onChange={e => setSelectedUserToGenerate(Number(e.target.value))}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-800"
                >
                  {users.map((u, idx) => (
                    <option key={`poster-user-${u.id}-${idx}`} value={u.id}>
                      {u.apellido}, {u.nombre} ({u.rol})
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* REAL HIGH-DENSITY QR CONTAINER */}
            <div className="p-6 bg-white inline-block rounded-3xl border-2 border-slate-200 shadow-xl mx-auto relative group">
              {/* Corner scan target accents */}
              <div className="absolute top-2 left-2 w-5 h-5 border-t-2 border-l-2 border-emerald-600 rounded-tl-lg pointer-events-none" />
              <div className="absolute top-2 right-2 w-5 h-5 border-t-2 border-r-2 border-emerald-600 rounded-tr-lg pointer-events-none" />
              <div className="absolute bottom-2 left-2 w-5 h-5 border-b-2 border-l-2 border-emerald-600 rounded-bl-lg pointer-events-none" />
              <div className="absolute bottom-2 right-2 w-5 h-5 border-b-2 border-r-2 border-emerald-600 rounded-br-lg pointer-events-none" />

              {qrDataUrl ? (
                <div className="relative">
                  <img
                    src={qrDataUrl}
                    alt="Código QR Real Scannable"
                    className="w-64 h-64 mx-auto rounded-xl shadow-inner transition-transform duration-300 group-hover:scale-[1.02]"
                  />

                  {/* Central Official School Seal */}
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-11 h-11 bg-white rounded-full p-1 shadow-md border-2 border-emerald-600 flex items-center justify-center pointer-events-none">
                    <img
                      src="/img/logo.png"
                      alt="Constancia"
                      className="w-full h-full object-contain"
                      onError={(e) => {
                        (e.currentTarget as HTMLImageElement).src = '/img/logoo.png';
                      }}
                    />
                  </div>

                  <div className="mt-3 text-center">
                    <span className="text-[11px] font-mono font-bold text-slate-700 bg-slate-100 px-3 py-1 rounded-full border border-slate-200">
                      {qrMode === 'station'
                        ? 'ESTACIÓN CENTRAL: PORT-01'
                        : `CARNET: ${activePosterUser?.apellido}, ${activePosterUser?.nombre}`}
                    </span>
                  </div>
                </div>
              ) : (
                <div className="w-64 h-64 flex flex-col items-center justify-center text-slate-400">
                  <RefreshCw className="w-8 h-8 animate-spin text-emerald-600 mb-2" />
                  <span className="text-xs font-bold">Generando Código QR...</span>
                </div>
              )}
            </div>

            {/* Styling and Download options */}
            <div className="flex items-center justify-center gap-2 mt-2">
              <button
                type="button"
                onClick={() => setQrColorStyle(qrColorStyle === 'institucional' ? 'negro' : 'institucional')}
                className="px-2.5 py-1 text-[11px] font-bold rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600 flex items-center gap-1 cursor-pointer"
              >
                <Palette className="w-3 h-3 text-amber-500" />
                {qrColorStyle === 'institucional' ? 'Ver en Negro Tradicional' : 'Ver en Color Institucional'}
              </button>

              {qrDataUrl && (
                <a
                  href={qrDataUrl}
                  download={`QR_Asistencia_La_Constancia_${qrMode}.png`}
                  className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100 flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3 h-3 text-emerald-600" />
                  Descargar Imagen PNG
                </a>
              )}
            </div>

            <div className="bg-emerald-50 border border-emerald-200 text-emerald-950 rounded-2xl p-3.5 max-w-md mx-auto my-3 text-xs flex items-center gap-2.5 text-left">
              <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>
                {qrMode === 'station'
                  ? 'Cartel scannable para imprimir o mostrar en portería. El personal puede escanearlo con la cámara de su teléfono móvil.'
                  : `Carnet individual de ${activePosterUser?.nombre} ${activePosterUser?.apellido}. Válido para ser leído por el lector óptico de portería.`}
              </span>
            </div>
          </div>
        )}

        {/* TAB 3: DIRECT SIMULATOR (Fast manual trigger for testing) */}
        {activeTab === 'simulator' && (
          <div className="max-w-md mx-auto bg-slate-50 border border-slate-200 rounded-3xl p-5 text-left space-y-4">
            <div>
              <h3 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider flex items-center gap-1.5 mb-1">
                <ScanLine className="w-4 h-4 text-emerald-600" />
                Marcaje Directo de Prueba
              </h3>
              <p className="text-[11px] text-slate-500">
                Permite simular el paso de un funcionario frente al lector óptico para verificar el cálculo de puntualidad y registro en base de datos.
              </p>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">
                Funcionario a marcar:
              </label>
              <select
                value={selectedUserToSimulate}
                onChange={e => setSelectedUserToSimulate(Number(e.target.value))}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-xl font-semibold text-slate-800"
              >
                {users.map((u, idx) => (
                  <option key={`sim-user-${u.id}-${idx}`} value={u.id}>
                    {u.apellido}, {u.nombre} ({u.rol.toUpperCase()} - {u.departamento || 'General'})
                  </option>
                ))}
              </select>
            </div>

            <button
              type="button"
              onClick={handleSimulateScan}
              className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer flex items-center justify-center gap-2"
            >
              <UserCheck className="w-4 h-4 text-amber-300" />
              Simular Lectura QR de Este Funcionario
            </button>
          </div>
        )}

        {/* OFFLINE QUEUE HUB (Always available if records are pending) */}
        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 max-w-md mx-auto mt-6 text-left space-y-3">
          <div className="flex items-center justify-between text-xs font-bold text-slate-700">
            <span className="flex items-center gap-1.5">
              <Database className="w-3.5 h-3.5 text-amber-600" />
              Cola de Registros Offline (Portería PWA)
            </span>
            <span className="bg-amber-100 text-amber-900 border border-amber-200 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold">
              {offlineQueue.length} registro(s)
            </span>
          </div>

          {offlineQueue.length > 0 ? (
            <div className="space-y-2">
              <div className="max-h-28 overflow-y-auto divide-y divide-slate-200 text-[11px] bg-white rounded-xl border border-slate-200 p-2">
                {offlineQueue.map((item, idx) => (
                  <div key={idx} className="py-1 flex items-center justify-between">
                    <span className="font-semibold text-slate-800">{item.nombre_completo}</span>
                    <span className="font-mono text-slate-500">{item.hora_str}</span>
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={handleSyncQueue}
                  className="flex-1 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition cursor-pointer shadow-sm"
                >
                  <RefreshCw className="w-3.5 h-3.5" /> Sincronizar Cola al Servidor
                </button>
                <button
                  onClick={handleExportOfflineBackup}
                  className="p-2 bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 rounded-xl text-xs transition cursor-pointer"
                  title="Descargar copia de seguridad CSV de los registros locales"
                >
                  <HardDriveDownload className="w-4 h-4" />
                </button>
              </div>
            </div>
          ) : (
            <p className="text-[11px] text-slate-400">
              No hay registros pendientes de sincronización. Todos los marcajes están actualizados en el libro central.
            </p>
          )}
        </div>

        {/* Footer Actions */}
        <div className="pt-6 border-t border-slate-100 flex items-center justify-between mt-6">
          <button
            onClick={() => onNavigate('director')}
            className="px-4 py-2 border border-slate-200 text-slate-700 hover:bg-slate-50 font-bold text-xs rounded-xl flex items-center gap-1.5 transition cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Volver al Panel
          </button>
          <button
            onClick={() => window.print()}
            className="px-5 py-2 bg-[#0C5528] hover:bg-[#072e19] text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-md transition cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5 text-amber-300" /> Imprimir Cartel de Portería
          </button>
        </div>
      </div>
    </div>
  );
};
