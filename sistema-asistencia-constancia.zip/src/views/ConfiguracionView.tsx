import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Settings,
  Clock,
  Calendar,
  ShieldCheck,
  AlertTriangle,
  RotateCcw,
  Palette,
  Sparkles,
  Sliders,
  Check,
  Eye
} from 'lucide-react';

export const ConfiguracionView: React.FC = () => {
  const {
    config,
    actualizarConfiguracion,
    resetToDefaults,
    palettes,
    currentPaletteId,
    primaryColor,
    accentColor,
    cambiarPaleta,
    cambiarColoresPersonalizados,
    resetearColoresInstitucionales,
  } = useApp();

  const [horaEntrada, setHoraEntrada] = useState(config.hora_entrada_oficial);
  const [horaSalida, setHoraSalida] = useState(config.hora_salida_oficial || '15:30');
  const [diasLaborables, setDiasLaborables] = useState<number[]>(config.dias_laborables);
  const [limitePermisos, setLimitePermisos] = useState<number>(config.limite_permisos);

  const [customPrimary, setCustomPrimary] = useState(primaryColor);
  const [customAccent, setCustomAccent] = useState(accentColor);

  const days = [
    { num: 0, label: 'Lun' },
    { num: 1, label: 'Mar' },
    { num: 2, label: 'Mié' },
    { num: 3, label: 'Jue' },
    { num: 4, label: 'Vie' },
    { num: 5, label: 'Sáb' },
    { num: 6, label: 'Dom' },
  ];

  const handleToggleDay = (dayNum: number) => {
    setDiasLaborables(prev =>
      prev.includes(dayNum) ? prev.filter(d => d !== dayNum) : [...prev, dayNum].sort()
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    actualizarConfiguracion({
      hora_entrada_oficial: horaEntrada,
      hora_salida_oficial: horaSalida,
      dias_laborables: diasLaborables,
      limite_permisos: Number(limitePermisos),
    });
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Title */}
      <div className="flex items-center gap-3 pb-3 border-b border-slate-200">
        <div className="w-12 h-12 rounded-full bg-white p-1 border-2 border-amber-400 shadow-md flex items-center justify-center overflow-hidden shrink-0">
          <img
            src="/img/logo.png"
            alt="Logo U.E. La Constancia"
            className="w-full h-full object-contain"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).src = '/img/logoo.png';
            }}
          />
        </div>
        <div>
          <h1 className="text-2xl font-extrabold text-slate-800 tracking-tight flex items-center gap-2">
            <Settings className="w-6 h-6 text-emerald-700" />
            Parámetros del Sistema
          </h1>
          <p className="text-xs text-slate-500 font-medium">
            U.E. "La Constancia" · Ajustes operacionales de control de entrada y personalización de marca
          </p>
        </div>
      </div>

      {/* SECCIÓN 1: PERSONALIZADOR DE IDENTIDAD VISUAL Y COLORES */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-8 space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div
              className="w-8 h-8 rounded-xl flex items-center justify-center text-white shadow-sm"
              style={{ backgroundColor: primaryColor }}
            >
              <Palette className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-slate-800">
                Personalización de Colores de la Institución
              </h2>
              <p className="text-xs text-slate-400">
                Ajuste dinámico e inmediato de la identidad visual del sistema
              </p>
            </div>
          </div>
          <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-emerald-600" /> En Tiempo Real
          </span>
        </div>

        {/* Paletas Predefinidas */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2.5">
            Paletas Rápidas
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {palettes.map(p => {
              const isSelected = currentPaletteId === p.id;
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => {
                    cambiarPaleta(p.id);
                    setCustomPrimary(p.primary);
                    setCustomAccent(p.accent);
                  }}
                  className={`p-3 rounded-2xl border text-left flex items-center justify-between transition cursor-pointer ${
                    isSelected
                      ? 'border-slate-800 bg-slate-50 shadow ring-2 ring-slate-800/10'
                      : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50/50'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <div className="flex items-center -space-x-1.5">
                      <span
                        className="w-5 h-5 rounded-full border border-white shadow-sm inline-block"
                        style={{ backgroundColor: p.primary }}
                      />
                      <span
                        className="w-5 h-5 rounded-full border border-white shadow-sm inline-block"
                        style={{ backgroundColor: p.accent }}
                      />
                    </div>
                    <span className="text-xs font-bold text-slate-800">{p.name}</span>
                  </div>
                  {isSelected && (
                    <span className="w-4 h-4 rounded-full bg-slate-800 text-white flex items-center justify-center">
                      <Check className="w-2.5 h-2.5" />
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Color Picker Personalizado */}
        <div className="pt-3 border-t border-slate-100">
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2 flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5" /> Color Picker Libre (Cualquier Color Solicitado)
          </label>
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl">
              <span className="block text-[11px] font-bold text-slate-600 mb-1">Color Primario</span>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={customPrimary}
                  onChange={e => {
                    setCustomPrimary(e.target.value);
                    cambiarColoresPersonalizados(e.target.value, customAccent);
                  }}
                  className="w-8 h-8 rounded-lg cursor-pointer bg-white border border-slate-200"
                />
                <input
                  type="text"
                  value={customPrimary}
                  onChange={e => {
                    setCustomPrimary(e.target.value);
                    if (/^#[0-9A-Fa-f]{6}$/.test(e.target.value)) {
                      cambiarColoresPersonalizados(e.target.value, customAccent);
                    }
                  }}
                  className="w-full text-xs font-mono font-bold px-2 py-1 bg-white border border-slate-200 rounded-lg"
                />
              </div>
            </div>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl">
              <span className="block text-[11px] font-bold text-slate-600 mb-1">Color Secundario</span>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={customAccent}
                  onChange={e => {
                    setCustomAccent(e.target.value);
                    cambiarColoresPersonalizados(customPrimary, e.target.value);
                  }}
                  className="w-8 h-8 rounded-lg cursor-pointer bg-white border border-slate-200"
                />
                <input
                  type="text"
                  value={customAccent}
                  onChange={e => {
                    setCustomAccent(e.target.value);
                    if (/^#[0-9A-Fa-f]{6}$/.test(e.target.value)) {
                      cambiarColoresPersonalizados(customPrimary, e.target.value);
                    }
                  }}
                  className="w-full text-xs font-mono font-bold px-2 py-1 bg-white border border-slate-200 rounded-lg"
                />
              </div>
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between">
            <button
              type="button"
              onClick={resetearColoresInstitucionales}
              className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1 font-semibold transition cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" /> Restablecer Colores La Constancia
            </button>
            <span className="text-[11px] text-emerald-700 font-bold flex items-center gap-1">
              <Eye className="w-3 h-3" /> Cambios aplicados automáticamente en vivo
            </span>
          </div>
        </div>
      </div>

      {/* SECCIÓN 2: HORARIO Y PUNTUALIDAD OFICIAL */}
      <div className="bg-white rounded-3xl border-l-4 border-l-amber-500 border border-slate-100 shadow-sm p-6 sm:p-8 space-y-6">
        <div className="pb-4 border-b border-slate-100">
          <h2 className="text-lg font-extrabold text-slate-800">
            Jornada Laboral y Límites de Entrada
          </h2>
          <p className="text-xs text-slate-400">
            Define la hora oficial a partir de la cual el escaneo QR o registro se computa con retardo.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-amber-500" /> Hora Oficial de Entrada
              </label>
              <input
                type="time"
                value={horaEntrada}
                onChange={e => setHoraEntrada(e.target.value)}
                required
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-800 focus:outline-none"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                Toda marcación posterior a esta hora se registrará como retardo.
              </span>
            </div>

            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-emerald-600" /> Hora Oficial de Salida
              </label>
              <input
                type="time"
                value={horaSalida}
                onChange={e => setHoraSalida(e.target.value)}
                required
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-800 focus:outline-none"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                Cierre del turno regular de la institución.
              </span>
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-amber-500" /> Días Laborables Hábiles
            </label>
            <div className="flex flex-wrap gap-2">
              {days.map(d => {
                const active = diasLaborables.includes(d.num);
                return (
                  <button
                    key={d.num}
                    type="button"
                    onClick={() => handleToggleDay(d.num)}
                    className={`px-3.5 py-2 rounded-xl font-bold text-xs transition cursor-pointer border ${
                      active
                        ? 'bg-[#0C5528] text-white border-[#0C5528] shadow-sm'
                        : 'bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {d.label}
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Límite de Permisos por Persona
            </label>
            <input
              type="number"
              min="0"
              max="20"
              value={limitePermisos}
              onChange={e => setLimitePermisos(Number(e.target.value))}
              required
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-800 focus:outline-none"
            />
            <span className="text-[11px] text-slate-400 mt-1 block">
              Cantidad máxima de solicitudes de permiso justificadas permitidas por año escolar.
            </span>
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={resetToDefaults}
              className="px-3.5 py-2.5 border border-slate-200 text-slate-500 hover:bg-slate-50 rounded-xl font-bold flex items-center gap-1.5 transition cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" /> Valores por Defecto
            </button>

            <button
              type="submit"
              className="px-6 py-2.5 text-white font-bold rounded-xl shadow-md transition cursor-pointer flex items-center gap-1.5 hover:brightness-110"
              style={{ backgroundColor: accentColor }}
            >
              <ShieldCheck className="w-4 h-4" /> Fijar Parámetros de Puntualidad
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
