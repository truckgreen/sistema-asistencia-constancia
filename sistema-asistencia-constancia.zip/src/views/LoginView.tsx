import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ThemeCustomizerModal } from '../components/ThemeCustomizerModal';
import {
  ShieldCheck,
  Mail,
  KeyRound,
  ArrowRight,
  Palette,
  Eye,
  EyeOff
} from 'lucide-react';

export const LoginView: React.FC = () => {
  const {
    login,
    primaryColor,
    accentColor,
  } = useApp();

  const [correo, setCorreo] = useState('director@institucion.edu');
  const [password, setPassword] = useState('admin123');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [themeModalOpen, setThemeModalOpen] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    const success = login(correo, password);
    if (!success) {
      setErrorMsg('Credenciales inválidas. Verifique su correo y contraseña institucional.');
    }
  };

  return (
    <div
      className="min-h-screen relative flex items-center justify-center p-4 transition-colors duration-500 overflow-hidden"
      style={{
        background: `radial-gradient(circle at 10% 20%, ${accentColor}dd 0%, ${primaryColor} 90%)`,
      }}
    >
      {/* Background Decorative Circles */}
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-white/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-white/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Floating Bar for Thesis Presentation / Jury */}
      <div className="absolute top-4 right-4 z-20 flex items-center gap-2">
        <button
          onClick={() => setThemeModalOpen(true)}
          className="px-3.5 py-2 rounded-2xl bg-white/20 hover:bg-white/30 backdrop-blur-md text-white text-xs font-bold flex items-center gap-2 border border-white/30 shadow-lg transition cursor-pointer"
          title="Personalizar color institucional en tiempo real"
        >
          <Palette className="w-4 h-4 text-amber-300" />
          <span>Cambiar Color Institucional</span>
        </button>
      </div>

      <div className="w-full max-w-md bg-white/95 backdrop-blur-xl border border-white/80 shadow-2xl rounded-3xl p-8 relative z-10 transition-all">
        {/* Official School Crest / Logo */}
        <div className="flex flex-col items-center justify-center mb-6">
          <div className="relative group mb-3">
            <div className="w-24 h-24 rounded-full bg-white p-1.5 shadow-xl border-2 border-amber-400/80 flex items-center justify-center overflow-hidden transition-transform duration-300 group-hover:scale-105">
              <img
                src="/img/logo.png"
                alt="Logo U.E. La Constancia"
                className="w-full h-full object-contain"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = '/img/logoo.png';
                }}
              />
            </div>
            <div
              className="absolute -bottom-1 -right-1 text-white rounded-full p-1.5 shadow-md"
              style={{ backgroundColor: primaryColor }}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
            </div>
          </div>

          <h1 className="text-xl font-extrabold text-slate-800 tracking-tight text-center">
            U.E. "LA CONSTANCIA"
          </h1>
          <div className="inline-block mt-0.5 px-2.5 py-0.5 rounded-full bg-slate-100 text-[10px] font-bold text-slate-500 uppercase tracking-widest">
            Hnos. Salvatorianos
          </div>
          <p className="text-xs text-slate-500 mt-1 font-medium text-center">
            Control de Asistencia, Horarios & Agenda Institucional
          </p>
        </div>

        {errorMsg && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs flex items-center gap-2 animate-in fade-in">
            <span className="w-2 h-2 rounded-full bg-red-500 shrink-0"></span>
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Correo Institucional
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                value={correo}
                onChange={e => setCorreo(e.target.value)}
                placeholder="director@institucion.edu"
                required
                className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-400/20 transition"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Contraseña de Acceso
            </label>
            <div className="relative">
              <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full pl-10 pr-10 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-400/20 transition"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3 px-4 text-white font-bold rounded-xl shadow-lg flex items-center justify-center gap-2 transition hover:brightness-110 cursor-pointer active:scale-[0.99]"
            style={{ backgroundColor: accentColor }}
          >
            <ArrowRight className="w-4 h-4" />
            Ingresar al Sistema
          </button>
        </form>

        {/* Nota Institucional Oficial */}
        <div className="mt-6 pt-5 border-t border-slate-100 text-center space-y-2">
          <p className="text-[11px] text-slate-500 font-medium">
            Acceso autorizado para el personal directivo, docente y administrativo de la <strong>U.E. "La Constancia"</strong>.
          </p>
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-slate-50 border border-slate-200 rounded-full text-[10px] text-slate-600 font-mono">
            <span>Directivo: <strong>director@institucion.edu</strong> (Clave: admin123)</span>
          </div>
        </div>
      </div>

      {/* Theme Customizer Modal */}
      <ThemeCustomizerModal
        isOpen={themeModalOpen}
        onClose={() => setThemeModalOpen(false)}
      />
    </div>
  );
};
